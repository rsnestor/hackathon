package com.fanniemae.lexbot.api;


import com.amazonaws.services.lambda.runtime.*;
import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Kashi on 6/8/2017.
 */
public class LexHandlerTest {

    @InjectMocks
    LexHandler lexHandler;

    OutputStream output = new OutputStream() {
        @Override
        public void write(int b) throws IOException {

        }
    };
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    Context context = new Context() {
        @Override
        public String getAwsRequestId() {
            return null;
        }

        @Override
        public String getLogGroupName() {
            return null;
        }

        @Override
        public String getLogStreamName() {
            return null;
        }

        @Override
        public String getFunctionName() {
            return null;
        }

        @Override
        public String getFunctionVersion() {
            return null;
        }

        @Override
        public String getInvokedFunctionArn() {
            return null;
        }

        @Override
        public CognitoIdentity getIdentity() {
            return null;
        }

        @Override
        public ClientContext getClientContext() {
            return null;
        }

        @Override
        public int getRemainingTimeInMillis() {
            return 0;
        }

        @Override
        public int getMemoryLimitInMB() {
            return 0;
        }

        @Override
        public LambdaLogger getLogger() {
            return null;
        }
    };

    @Test
    public void testStateWithValues() throws IOException {

        //jsonParser("/intent-sample1.json");
        InputStream is = LexHandlerTest.class.getResourceAsStream("/intent-state.json");
        lexHandler.handleRequest(is, output, context);
    }

    @Test
    public void testStateWithDefaultValues() throws IOException {

        //jsonParser("/intent-sample1.json");
        InputStream is = LexHandlerTest.class.getResourceAsStream("/intent-state-default.json");
        lexHandler.handleRequest(is, output, context);
    }

    public void jsonParser(String fileName) throws IOException {
        InputStream is = LexHandlerTest.class.getResourceAsStream(fileName);
        String jsonStr = IOUtils.toString(is);
        Map<String, String> map = JsonPath.from(jsonStr).get("currentIntent.slots");
        JsonPath.from(jsonStr).get("currentIntent.name");
//        Jackson2JsonObjectMapper jackson2Json = new Jackson2JsonObjectMapper();

//        try {
//            String result = jackson2Json.fromJson(jsonStr,map);
//            System.out.println(result);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}