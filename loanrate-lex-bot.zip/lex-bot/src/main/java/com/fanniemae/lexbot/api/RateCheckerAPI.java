package com.fanniemae.lexbot.api;

import com.fanniemae.lexbot.model.RateModel;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Kashi on 6/8/2017.
 */

public class RateCheckerAPI {
    private static final Logger LOGGER = Logger.getLogger(RateCheckerAPI.class);


    private RestTemplate restTemplate;

    public String getRate(String paramStr) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://www.consumerfinance.gov/oah-api/rates/rate-checker?" + paramStr;
        LOGGER.info("url: "+ url);
        String resp = "bad-request";
        try {
            resp = restTemplate.getForObject(url, String.class);
        }catch (Exception e){
            e.printStackTrace();

        }
        return resp;
    }

    public static void main(String[] args) {
        StringBuffer b = new StringBuffer();
        b.append("loan_type").append("=").append("AGENCY")
                .append("&").append("loan_amount").append("=").append("50000")
                .append("&").append("loan_term").append("=").append("30")
                .append("&").append("maxfico").append("=").append("750")
                .append("&").append("minfico").append("=").append("650")
                .append("&").append("price").append("=").append(725000)
                .append("&").append("rate_structure").append("=").append("FIXED")
                .append("&").append("state").append("=").append("VA");
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://www.consumerfinance.gov/oah-api/rates/rate-checker?" + b.toString();
//        String rateModel =
//
//                restTemplate.getForObject(url,
//                        String.class);

        String t = "\"[12.33]\"";

        System.out.println(t.replaceAll("\"", "")
                .replaceAll("\\[","")
                .replaceAll("]","")
        );
    }
}
