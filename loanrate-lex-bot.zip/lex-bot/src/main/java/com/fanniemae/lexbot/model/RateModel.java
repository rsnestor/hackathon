package com.fanniemae.lexbot.model;

import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Kashi on 6/8/2017.
 */
@Data
public class RateModel {
    private Data data;

    @lombok.Data
    private static class Data {
        private List<Map<String, String>> list;
    }
}