package com.fanniemae.lexbot.api;


import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.amazonaws.services.lexruntime.AmazonLexRuntimeClientBuilder;
import com.amazonaws.util.IOUtils;
import com.google.common.base.Joiner;
import com.jayway.restassured.path.json.JsonPath;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * Created by Kashi on 6/8/2017.
 */
public class LexHandler implements RequestStreamHandler {
    private static final Logger LOGGER = Logger.getLogger(LexHandler.class);

    @Override
    public void handleRequest(InputStream input, OutputStream output, Context context) throws IOException {
        String content = IOUtils.toString(input);

        LOGGER.info("content: " + content);

        String currentIntent = JsonPath.from(content).get("currentIntent.name");
        String response = "";
        if ("state".equalsIgnoreCase(currentIntent)) {
            response = stateIntentWorkFlow(content);
        } else {
            countyIntentWorkFlow(content);
        }

        OutputStreamWriter writer = new OutputStreamWriter(output, "UTF-8");
//        writer.write("{ \"sessionAttributes\": {}, \"dialogAction\": { \"type\": \"Close\", " +
//                "\"fulfillmentState\": \"Fulfilled\", \"message\": { \"contentType\": \"PlainText\", \"content\": " +
//                "\"Director :world\" } } }");
        writer.write(response);
        writer.close();

    }

    public void countyIntentWorkFlow(String content) {
    }

    public String stateIntentWorkFlow(String content) {
        Map<String, String> slotsMap = JsonPath.from(content).get("currentIntent.slots");
        return makeUpDefaultValuesForNonExist(slotsMap);
    }

    private String makeUpDefaultValuesForNonExist(Map<String, String> slotsMap) {

        InputStream defaultResp = null;
        Map<String, String> modSlotsMap = new HashMap<>();
        InputStream is = LexHandler.class.getResourceAsStream("/loan-config.json");
        try {
            String defaultStr = IOUtils.toString(is);

            //required
            String loan_type = slotsMap.get("loan_type");
            if (isEmpty(loan_type)) {
                loan_type = JsonPath.from(defaultStr).get("loan_type.default");
            }
            slotsMap.put("loan_type", loan_type);

            //required
            String maxfico = slotsMap.get("maxfico");
            if (isEmpty(maxfico)) {
                maxfico = JsonPath.from(defaultStr).get("maxfico.default");
            }
            slotsMap.put("maxfico", maxfico);

            //required
            String minfico = slotsMap.get("minfico");
            if (isEmpty(minfico)) {
                minfico = JsonPath.from(defaultStr).get("minfico.default");
            }
            slotsMap.put("maxfico", minfico);

            //required
            String rate_structure = slotsMap.get("rate_structure");
            if (isEmpty(rate_structure)) {
                rate_structure = JsonPath.from(defaultStr).get("rate_structure.default");
            }
            slotsMap.put("rate_structure", rate_structure);

            //required - state - bad request
//            String state = slotsMap.get("state");
//            if (isEmpty(state)) {
//                state = JsonPath.from(defaultStr).get("state.default");
//            }
//            slotsMap.put("state", state);

            //required
            String loan_amount = slotsMap.get("loan_amount");
            if (isEmpty(loan_amount)) {
                loan_amount = JsonPath.from(defaultStr).get("loan_amount.default");
            }
            slotsMap.put("loan_amount", loan_amount);

            //required
            String loan_term = slotsMap.get("loan_term");
            if (isEmpty(loan_term)) {
                loan_term = JsonPath.from(defaultStr).get("loan_term.default");
            }
            slotsMap.put("loan_term", loan_term);

            String str = Joiner.on("&").withKeyValueSeparator("=").join(slotsMap);

            RateCheckerAPI api = new RateCheckerAPI();
            String resp = api.getRate(str);


            if (resp.equalsIgnoreCase("bad-request")) {
                defaultResp = LexHandler.class.getResourceAsStream("/lex-response.json");
            }
            LOGGER.info("resp: " + resp);
            String actualResponse = IOUtils.toString(defaultResp);
            return actualResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}